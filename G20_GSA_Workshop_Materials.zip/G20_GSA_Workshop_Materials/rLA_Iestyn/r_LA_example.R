# install.packages('rLakeAnalyzer')
library(rLakeAnalyzer)

setwd('.../Tutorial/Sparkling')

# load water temperature  data for Sparkling Lake
wtr <- load.ts('Sparkling.wtr')

# extract the water temperature depth information from the headers
depths <- get.offsets(wtr)

# load wind speed data
wnd <- load.ts('Sparkling.wnd')

# load bathymetry data
bathy <- load.bathy('Sparkling.bth')

# plot the water temperature profile data as a heat map
wtr.heat.map(wtr)

# calculate the whole lake temperature, but change default temperature range to 0-30C
wtr.heat.map(wtr, zlim=c(0,30), plot.title="Sparkling Water Temp (C)")

#calculate and plot the depth of the epilimnion and hypolimnion (also known as the top and bottom of the metalimnion)
md <- ts.meta.depths(wtr)
plot(md$datetime, md$top, type='l', ylab='Meta Depths (m)', xlab='Date', col='blue')
lines(md$datetime, md$bottom, col='red')

# calculate the depth of the thermocline
thermod <- ts.thermo.depth(wtr, Smin = 0.1, na.rm = FALSE)
plot(thermod, type='l', ylab='Thermocline depth (m)', xlab='Date', col='black')

#add to the heat map a line for thermocline depth and the top and bottom of the hypolimnion
wtr.heatmap.layers(wtr)

# get and plot the volumetrically averaged temperature of the epilimnion
layer_temp <- ts.layer.temperature(wtr, 4, 8, bathy, na.rm = FALSE)
plot(layer_temp, type='l', ylab='C', xlab='Date', col='black')

# calculate and plot the schmidt stability
st <- ts.schmidt.stability(wtr, bathy, na.rm = FALSE)
plot(st, type='l', ylab='Schmidt stability (Jm-2)', xlab='Date', col='black')

# calculate the wind friction velocity
ustar <- ts.uStar(wtr, wnd, 2, bathy)
plot(ustar, type='l', ylab='Wind friction velocity (Nm-2)', xlab='Date', col='black')