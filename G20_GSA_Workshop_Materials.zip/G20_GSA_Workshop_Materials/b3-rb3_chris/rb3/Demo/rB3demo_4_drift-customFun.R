#********************************** rB3 DEMONSTRATION SCRIPT #4  *******************************************#

## prepared for GLEON 20, GSA workshop 2018-12-03  ##

#@@@@   Chris McBride & Kohji Muraoka, UoW, November 2018, correspondance to cmcbride@waikato.ac.nz    @@@@@#

################################   ADVANCED AND CUSTOM FUNCTIONS   #########################################

# library(rB3)
# Sys.setenv(TZ = "UTC")

#**********************************************************************************************************#

# !! import rB3 custom functions (stored in 'customFun' folder in your directory)
# lapply(paste0("../../rB3-master/customFun/", 
#               list.files(path = "../../rB3-master/customFun", pattern = "[.]R$", recursive = TRUE)), source)

#**********************************************************************************************************#
                                  # backup of demo data loading #
# # load data
# rB3demo <- csv2rB3("rB3demo_201507-201806_RAW_R.csv","Lake_Rotoehu",-38.5,176.5,"NZ",TRUE)
# 
# # aggregation can take a while on big DFs! (dev task to speed this up)
# rB3agg <- rB3stdze(rB3in = rB3demo, varNames = 'All', startDate = '2016-07-01', endDate = '2018-06-30 23:45:00',
#                      timestep = 15)
# 
#**********************************************************************************************************#

shinyrB3(rB3agg2)

#************************************** ADVANCED FUNCTIONS ************************************************#

#### revert to original (aggregated) data frame
# rB3agg2 <- rB3agg
         
?applyNth          
# apply a mathematical transformation, e.g. new = a + b(old) + c(old)^2 + c(old)^3 + ...etc
rB3agg2 <- applyNth(rB3in = rB3agg2,'2016-07-01 00:00:00','2017-06-28 23:45:00',
                    'DOpsat.d00050',coeffs = c(12,1,0.02), showPlot = TRUE)


?driftCorr
# correct linear sensor drift (assumes consistent timestep)
rB3agg2 <- driftCorr(rB3agg2,'2016-07-01 00:00:00','2017-06-28 23:45:00','DOpsat.d00050',
                     lowRef = 0,    lowStart =  0,  lowEnd =  0, 
                     highRef = 100, highStart = 85, highEnd = 130)#,
                     #showPlot = TRUE)


#*************************************** CUSTOM FUNCTIONS ************************************************#

#view winter tempr data
rB3gg(rB3in = rB3agg2, varNames = 'TmpWtr', startDate = '2017-07-01', endDate = '2017-08-01',  
      facet = FALSE, savePlot = 'figures/Before_')#, 


?tmprAlign
# post-calibrate temperature sensors based on periods of mixing, as found by temp differences and wind speed
rB3agg2 <- tmprAlign(rB3agg2, varNames = 'TmpWtr',
                     dTPerctile = 0.2, 
                     logID = "tpmAlign", Reason = "Interp", showPlot = T, plotType = 'All')


#view winter tempr data
rB3gg(rB3in = rB3agg2, varNames = 'TmpWtr', startDate = '2017-07-01', endDate = '2017-08-01',  
      facet = FALSE, savePlot = 'figures/After_')#, 


#***************************** WRITE AND APPLY YOUR OWN CUSTOM FUNCTION **************************************#

?FUNCrB3
# apply a custom function using rB3

                              # simple example: multiply a variable by 2

# define a simple function ( result = input variable * 2)
test <- function(eqnVars) {eqnVars[1] * 2}

# apply this custom function
rB3agg2 <- FUNCrB3(rB3agg2, varNames = 'DOpsat.d00050', 
                   eqnVars = 'DOpsat.d00050', FUN = test, showPlot = T)


#         complex example: calculate DO (mg/L) using ( DO (%sat) and water temperature ) using USGS method..
#
#                                     Meyers, D.N. (2011)   https://water.usgs.gov/admin/memo/QW/qw11.03.pdf
#
#
# eqn:  DOmg = (exp(-139.34411 + ((157570.1*(1/( tmpwtr +273.15))) + (-66423080*((1/( tmpwtr +273.15))^2)) + 
#          (12438000000*((1/( tmpwtr +273.15))^3)) + (-862194900000*((1/( tmpwtr +273.15))^4))))) * DOsat *0.01
# 
# ..where tmpwtr = water temperature and DOsat = dissolved oxygen saturation

rB3gg(rB3agg2,varNames = c('DOpsat.d00050','DOconc.d00050'), 
      showPlot = T, srcColour = 'orange', qcColour = 'blue')


# define the list of input variables required for the calculation
eqnVars = c('TmpWtr.d00050','DOpsat.d00050')

# define the function, using eqnVars[1] - tmpwtr and eqnVars[2] = DOsat
DOsat2mg <- function(eqnVars) {
  (exp(-139.34411 + ((157570.1*(1/( eqnVars[1] +273.15))) + 
      (-66423080*((1/( eqnVars[1] +273.15))^2)) + 
        (12438000000*((1/( eqnVars[1] +273.15))^3)) + 
           (-862194900000*((1/( eqnVars[1] +273.15))^4))))) * eqnVars[2] * 0.01
}

?FUNCrB3
rB3agg2 <- FUNCrB3(rB3agg2, varNames = 'DOconc.d00050', 
                   eqnVars = eqnVars, FUN = DOsat2mg, showPlot = T)



#************************** writeLAinputs() WRITE LAKE ANALYZER INPUT FILES ******************************#
                                

# write cleaned up temperature and wind data to .wtr and .wnd files for direct input to rLakeAnalyzer
?writeLAinputs
writeLAinputs(rB3in = rB3agg2, wtrNames = 'TmpWtr', wndName = 'WndSpd', wndHeight = 1.5)


#*********************************************** fin *****************************************************#




