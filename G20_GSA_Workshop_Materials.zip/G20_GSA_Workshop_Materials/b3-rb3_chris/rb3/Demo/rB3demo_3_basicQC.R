#********************************** rB3 DEMONSTRATION SCRIPT #3  *******************************************#

                          ## prepared for GLEON 20, GSA workshop 2018-12-03  ##

#@@@@   Chris McBride & Kohji Muraoka, UoW, November 2018, correspondance to cmcbride@waikato.ac.nz    @@@@@#

################################   BASIC QUALITY CONTROL OPERATIONS   #######################################

# library(rB3)
# Sys.setenv(TZ = "UTC")

#**********************************************************************************************************#
                                # backup of demo data loading, if needed #
# # load data
# rB3demo <- csv2rB3("rB3demo_201507-201806_RAW_R.csv","Lake_Rotoehu",-38.5,176.5,"NZ",TRUE)
# 
# # aggregation can take a while on big DFs! (dev task to speed this up)
# rB3agg <- rB3stdze(rB3demo, varNames = 'All', startDate = '2016-07-01', endDate = '2018-06-30 23:45:00',
#                      timestep = 15)

#**********************************************************************************************************#
# backup the aggregated data frame, in case we want to revert later
rB3agg2 <- rB3agg

shinyrB3(rB3agg2)

#*********************************# assignVal() - DELETE OR CHANGE DATA #**********************************#
                                  
?assignVal
# replace values in specified regions of data with a numerical value or with NA

# !!!!! select a region from your shiny plot containing erroneous data, then paste the example function, e.g.:
rB3agg2 <- assignVal(rB3agg2, varNames = "TmpWtr.d00050",  
                     startDate = "2017-06-16 18:45:51", endDate = "2017-07-10 13:23:43", 
                     minVal = 12.1, maxVal = 22.7, newVal = NA, logID = "Shiny", Reason = "Manual removal", showPlot = T)

#**************************************# APPLY FILTERS FROM 'ctrls' #***************************************#
                                              
?filterRoc
# replace values exceedign specified rate of change with NA
rB3agg2 <- filterRoc(rB3agg2, varNames = c('TmpWtr.d00050','TmpWtr.d00150'), 
                     maxRoc = 0.5, showPlot = TRUE)

# ! if showPlot is TRUE, so you must enter your choice (1 = accept, 2 = decline) to continue

?filterReps
# replace data where identical value has been repeated more than n = maxReps
rB3agg2 <- filterReps(rB3agg2, varNames = c('TmpWtr.d00050','TmpWtr.d00150'), 
                      maxReps = 20, showPlot = TRUE)


?filterMinMax
# filter data below minVal or above maxVal (either specified, or from 'ctrls'/headers)
rB3agg2 <- filterMinMax(rB3agg2, varNames = c('TmpWtr.d00050','TmpWtr.d00150'), 
                       filterMin = 9, filterMax = 25, showPlot = TRUE) # savePlot = 'figures/testPlot_')

#*****************************# applyInterp() - INTERPOLATE MISSING DATA #**********************************#

?applyInterp
# linearly interpolate NA values
rB3agg2 <- applyInterp(rB3agg2, varNames = c('TmpWtr.d00050','TmpWtr.d00150'), 
                       maxNArep = 50000, showPlot = TRUE)


#********************** logsPlot() - visualise source, QC data and modifications log ***********************#

?logsPlot                                   
# visualise changes to data
logsPlot(rB3in = rB3agg2, varNames = c('TmpWtr.d00050','TmpWtr.d00150'), srcColour = 'grey', 
            showPlot = TRUE) #, savePlot = 'figures/RAW_WQ_',  dpi = 400)


?rB3gg
# view the final before and after, without logs
rB3gg(rB3in = rB3agg2, varNames = c('TmpWtr.d00050','TmpWtr.d00150'), facet = TRUE, 
            srcColour = 'orange', qcColour = 'blue') #, savePlot = 'figures/RAW_WQ_',  dpi = 400)



#********************************** # rB3export() EXPORTING rB3 DATA #***************************************#

?rB3export
# export data from the rB3 object into csv files
rB3export(rB3agg, varNames = 'All', qc = T, src = T, metadata = T)

#**************************** Go to script #4 - custom functions ********************************************#




