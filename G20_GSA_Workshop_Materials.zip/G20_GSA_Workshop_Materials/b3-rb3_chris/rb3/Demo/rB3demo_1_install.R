#********************************** rB3 DEMONSTRATION SCRIPT #1  *******************************************#
 
                       ## prepared for GLEON 20, GSA workshop 2018-12-03  ##

#@@@@   Chris McBride & Kohji Muraoka, UoW, November 2018, correspondance to cmcbride@waikato.ac.nz    @@@@@#

##########################################   INSTALLING rB3   ###############################################


# you'll need to have or install the R packages 'devtools', 'tidyr', ggplot2', 'lubridate', 'shiny' & circular'
# and the rB3 base package (maintain the folder structure provided and this should work)


##### If installing packages failed, manually install dependencies below:
# install.packages("tidyr")
# install.packages("ggplot2", dependencies = TRUE)
# install.packages("lubridate")
# install.packages("shiny")
# install.packages("circular")


#************************# Web installation via git ('remotes' OR 'devtools') #**************************#

### via package "remotes" 
# install.packages("remotes")
# library(remotes)
 remotes::install_github("kohjim/rB3", ref = "G20")

###via package "devtools"
# install.packages("devtools")
# library(devtools)
 devtools::install_github("kohjim/rB3", ref = "G20")
 

library(rB3)

#***************************************# Local installation #*********************************************#

 ### download directly from github
 # https://github.com/kohjim/rB3/archive/G20.zip

 # !!! Open the folder 'Demo' and the file Demo.Rproj !!! #
 
# check your working directory, and adjust if needs be
getwd()
# setwd("C:/")

#install rB3
library(devtools)
install("../rB3-G20")

# load the rB3 library
library(rB3)

#******************* Ready to go! Go to script 2 - loading and manipulating datasets **************************#
