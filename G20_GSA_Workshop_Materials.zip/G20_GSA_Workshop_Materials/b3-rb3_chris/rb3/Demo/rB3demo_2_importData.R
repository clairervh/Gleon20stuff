#********************************** rB3 DEMONSTRATION SCRIPT #2  *******************************************#

                         ## prepared for GLEON 20, GSA workshop 2018-12-03  ##

#@@@@   Chris McBride & Kohji Muraoka, UoW, November 2018, correspondance to cmcbride@waikato.ac.nz    @@@@@#

#############################   IMPORTING, EXPORTING & DATA VISUALISATION   ####################################

# SET SYSTEM TIMEZONE TO UTC! why?..
#    ..the POSIXct date format used by rB3 can play havoc with your data editing if timezones are not handled well..
#    ..so it can help to set your system environment to UTC, which avoids issues with tz offsets
Sys.setenv(TZ = "UTC")

library(rB3)
#********************************#   csv2rB3() - IMPORT A RAW DATASET   #***********************************#

# import a starting .csv file, which will be converted into a list of data frames:
#     1. the raw data block from your csv file;                                           'srcDF'
#     2. a copy of the raw data block, to be quality controlled;                          'qcDF'
#     3. a matrix with similar dimensions to 1 & 2, to store qc action logID values;      'logDF'
#     4. a list of logID values and their meanings;                                       'logKey'
#     5. sensor/time-series metadata and control values used for filtering/plotting etc   'ctrls'
#     6. site/station meta data                                                           'metaD'

## documentation
?csv2rB3

# intial csv header rows can contain time-series/sensor metadata to be used in later functions (loaded as 'ctrls' DF within list)
# row prior to start of data will be data frame headers
#        date format must be yyyy-mm-dd hh:mm:ss, with header "DateTime"
rB3demo <- csv2rB3("rB3demo_201507-201806_RAW_R.csv","Lake_Rotoehu",-38.5, 176.5,"NZ")

#call the components of the rB3 object on the fly (not needed for rB3 operations)
names(rB3demo)

#e.g.,
 testDF <- rB3demo[["ctrls"]]


#*******************# shinyrB3() INVESTIGATE YOUR DATA INTERACTIVELY USING SHINY ###### ********************#
                      
# documentation
?shinyrB3

shinyrB3(rB3demo)
# note that shiny occupies R studio so you need to shut the Shiny window in order to action any more commands..



#************************************# SELECTING VARIABLES IN rB3 #****************************************# 
                                     
# variables can be called using key phrases/characters (i.e., all vars containing key word will be selected)
# create vector of key phrases, for later functions, e.g.;
wqVars <- c('Fl','Tur','pH','DO')

?rB3getVars
# retrieve varNames; 'All' (default) or select by keyphrase
rB3getVars(rB3demo, 'TmpWtr')



#*****************************# rB3stdze() - TRIM AND STANDARDIZE DATA FRAMES #********************************# 
                              
# our demo rawDF has 3 yrs data, some with 5 min data, some 15 min..
# ..so let's trim dataset to most recent 2 years, and aggregate to common (15 min) timestep, 
#     using aggregation methods specific to each column as defined in the header metadata (ctrls$methodAgg)
#     for example, here we'll aggregate by mean, but sum for rainfall, and circular averaging for wind direction 

?rB3stdze
# aggregate the data to 15 min timestep - can take a while on big DFs!
rB3agg <- rB3stdze(rB3demo, varNames = 'All', startDate = '2016-07-01', endDate = '2018-06-30 23:45:00',
                   timestep = 15, aggAll = FALSE)


#*****************************# varWrangle() - CREATE, REMOVE, MOVE VARIABLES #********************************# 
?varWrangle

# add variable(s) after 3rd variable (3rd excluding DateTime)
rB3agg <- varWrangle(rB3agg, 
                     varNames = "TESTVAR", 
                     task = "add",
                     loc = 4)

rB3getVars(rB3agg)


# remove variable(s) by "keyword" TESTVAR
rB3agg <- varWrangle(rB3agg, 
                     varNames = "TESTVAR", 
                     task = "rm")

rB3getVars(rB3agg)

#**********************************# gg_facetVar() - BASIC PANEL PLOTS #**************************************# 

?rB3gg                                     
# plot the variables called by the keywords in wqVars, saved to figures dir
rB3gg(rB3in = rB3agg, varNames = wqVars, srcColour = 'grey34', facet = TRUE,
                showPlot = TRUE , savePlot = 'figures/RAW_WQ_',  dpi = 400)

rB3gg(rB3in = rB3agg, varNames = 'DOp', srcColour = 'grey34', facet = FALSE,
      showPlot = TRUE , savePlot = 'figures/RAW_WQ_',  dpi = 400)


#************************************** Go to script 3 - QAQC basics ****************************************#